---
name: Gallant Football Performance
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e5bdbe'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#ac8889'
  outline-variant: '#5c3f40'
  surface-tint: '#ffb3b6'
  primary: '#ffb3b6'
  on-primary: '#68001a'
  primary-container: '#e11d48'
  on-primary-container: '#fffaf9'
  inverse-primary: '#be0037'
  secondary: '#ffb4ab'
  on-secondary: '#690005'
  secondary-container: '#bb0112'
  on-secondary-container: '#ffc8c1'
  tertiary: '#ffb2b7'
  on-tertiary: '#67001b'
  tertiary-container: '#db2b4e'
  on-tertiary-container: '#fffaf9'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b6'
  on-primary-fixed: '#40000c'
  on-primary-fixed-variant: '#920028'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ab'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000b'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-xl:
    fontFamily: Barlow Condensed
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
  headline-xl-mobile:
    fontFamily: Barlow Condensed
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
  headline-lg:
    fontFamily: Barlow Condensed
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Barlow Condensed
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Barlow Condensed
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Barlow Condensed
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Outfit
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Outfit
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Barlow Condensed
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 20px
  label-md:
    fontFamily: Barlow Condensed
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Barlow Condensed
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-octane, elite athletic atmosphere tailored for youth football development, competitive scouting, and player management. The aesthetic blends high-contrast athletic brutalism with refined dark-mode glassmorphic touches, evoking the prestige of professional European academy facilities illuminated by floodlights under the night sky.

The target audience comprises aspirational youth athletes (ages 6–18), prospective parents seeking professional development structures, and academy scouts analyzing performance metrics. The emotional response is geared toward empowerment, discipline, intensity, and aspirational professionalism. 

Visual characteristics include pitch-black canvas depths, sharp crystalline border highlights, energetic crimson and laser-red neon accents, vertical racing stripes reminiscent of academy kit traditions, and condensed, impactful typography engineered for rapid scanning on mobile screens.

## Colors

The palette leverages a high-contrast dark foundation anchored by pure pitch obsidian, deep carbon tiers, and aggressive crimson flashes:

- **Primary (`#E11D48`)**: High-intensity athletic crimson used for core interactive focal points, active state highlights, and primary key performance indicators.
- **Secondary (`#DC2626`)**: Deep blood red utilized for badge shields, kit stripe accents, danger states, and intense energy gradients.
- **Tertiary (`#F43F5E`)**: Vibrant laser scarlet used exclusively for glowing borders, pulsing status indicators, and mobile touch highlights.
- **Neutral Canvas (`#0A0A0A`)**: Ground-zero pitch black, paired with `#121212` (Card Base), `#1A1A1A` (Elevated Card), and `#262626` (Subtle Athletic Outlines).
- **Text & Foreground**: Pure White (`#FFFFFF`) provides maximum readability against pitch surfaces, complemented by Silver Mist (`#94A3B8`) for secondary stats, match records, and metadata.

## Typography

The type system blends the energetic compression of **Barlow Condensed** for uppercase athletic headings with the clean, modern geometric legibility of **Outfit** for analytical telemetry and narrative copy.

- **Display & Headings**: Rendered in uppercase Barlow Condensed with tight tracking (`-0.01em` to `0.02em`) to mimic sports broadcast scoreboards and player kit typography.
- **Body & Data**: Rendered in Outfit to guarantee effortless legibility for performance logs, training program breakdowns, and parent portal communication on handheld mobile screens.
- **Labels & Badges**: Set in Barlow Condensed Semibold or Bold, always uppercase, with slightly expanded letter-spacing (`0.05em`) for optimal legibility at micro scales.

## Layout & Spacing

The layout is built mobile-first, adhering to an intense athletic rhythm that balances compact data-density with thumb-friendly touch zones:

- **Mobile Viewport Focus**: Uses a 4-column layout on mobile with `1rem` (`16px`) side margins and `0.75rem` gutters. Touch targets maintain a minimum vertical height of 48px to accommodate quick physical interaction during pitch-side usage.
- **Desktop & Tablet Scaling**: Scales to an 8-column grid on tablets and a 12-column grid on desktop screens (max-width `1280px`), transitioning outer margins to `2rem` (`32px`).
- **Vertical Rhythm**: Content blocks leverage `space-lg` (`24px`) for intra-card relationships and `space-xl` (`40px`) for section segregation, ensuring high velocity through scrolling experiences without visual fatigue.

## Elevation & Depth

Visual hierarchy on pure dark canvas surfaces is established through luminous neon borders, subtle pitch-black gradients, and selective crimson back-glows:

- **Level 0 (Pitch Ground)**: Canvas background `#0A0A0A` with optional subtle carbon carbon-fiber or grass turf grain overlay at 3% opacity.
- **Level 1 (Card Bases & Containers)**: Surface fill `#121212` with a 1px perimeter stroke of `rgba(255, 255, 255, 0.08)`. No traditional drop shadows; physical separation is rendered purely through contrast.
- **Level 2 (Active/Hover Cards)**: Surface fill `#1A1A1A` enclosed in a dual border: an interior hairline stroke `rgba(225, 29, 72, 0.3)` and an exterior atmospheric glow: `0px 8px 24px -4px rgba(225, 29, 72, 0.25)`.
- **Level 3 (Modals, Overlays & Sticky Navbars)**: Acrylic backdrop blur (`backdrop-filter: blur(16px)`) with `rgba(10, 10, 10, 0.85)` pitch grounding and a bottom luminous hairline border tinted in `#E11D48`.

## Shapes

The design system incorporates a disciplined, semi-sharp geometry (`roundedness: 1`). Radii stay tight (`4px` to `8px`) to preserve the sharp, competitive attitude of professional athletic crests, speed chevrons, and stadium architectural framework.

- Buttons and interactive inputs employ a crisp `4px` corner bevel.
- Cards, modal containers, and player stat shields utilize `8px` (`rounded-lg`) borders.
- Badges and numerical kit counters maintain strict rectangular or slightly softened rectangular profiles rather than generic bubble pills, accentuating speed and aerodynamic precision.

## Components

### Buttons
- **Primary Athletic Button**: Solid crimson background (`#E11D48`), white bold condensed text (`Barlow Condensed`, uppercase), 4px border radius, subtle hover transition to `#DC2626` with an inner top hairline highlight (`rgba(255, 255, 255, 0.2)`). Height: 48px on mobile.
- **Ghost/Outline Button**: Transparent background, 1.5px border in `rgba(255, 255, 255, 0.2)` transitioning to `#E11D48` on hover/active. Silver-to-white text.
- **Pulsing Action Button**: Equipped with an animated glowing perimeter outline using the tertiary crimson hue for priority actions like "Book Trial" or "Register for Tryouts".

### Cards & Player Profiles
- **Academy Stat Card**: Constructed on `#121212` with a razor-thin 1px border (`#262626`). Features a 3px vertical crimson racing strip along the left edge. Header features the player position and jersey number formatted in condensed tabular figures.
- **Drill & Match Fixture Card**: Employs split sections; top area showcases high-contrast match timing, opponent crest, and venue badges against a dark gradient backdrop, while the bottom section holds team rosters and coaching notes.

### Input Fields & Controls
- **Input Fields**: Matte dark background (`#161616`), 1px outline in `#2A2A2A`, white text, silver placeholders (`#94A3B8`). On focus, the border flashes to `#E11D48` accompanied by a localized `0 0 8px rgba(225, 29, 72, 0.35)` glow.
- **Checkboxes & Radios**: Angular 4px squares with crimson check fills and high-contrast white glyphs.

### Chips & Badges
- **Category Chips**: Deep obsidian background with a 1px border. In active state: filled with a 15% crimson tint, vibrant crimson text (`#F43F5E`), and a 1px border in `#E11D48`.
- **Status Badges**: (e.g., "U-14 ELITE", "MATCHDAY", "SCOUT VERIFIED") Micro caps set in `label-sm`, accompanied by a 6px circular neon dot indicator.

### Academy Specific Components
- **Kit Stripe Separator**: Decorative component featuring 4 vertical crimson bars inspired by the academy crest, used as a section divider across landing and player highlight screens.
- **Tactical Pitch Visualizer**: Dark turf green/charcoal pitch canvas (`#0d140e`) with crisp white pitch lines at 20% opacity and neon red positional markers.